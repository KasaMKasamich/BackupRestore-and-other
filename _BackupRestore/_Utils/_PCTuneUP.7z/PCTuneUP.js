var WSHShell = WScript.CreateObject("WScript.Shell");
WSHShell.Run("C:/_BackupRestore/_PCTuneUP.cmd",0);