var WSHShell = WScript.CreateObject("WScript.Shell");
WSHShell.Run("H:/_BackupRestore/_BackUpFiles.cmd",0);