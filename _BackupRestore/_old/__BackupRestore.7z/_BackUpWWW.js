var WSHShell = WScript.CreateObject("WScript.Shell");
WSHShell.Run("H:/_BackupRestore/_BackUpWWW.cmd",0);