var WSHShell = WScript.CreateObject("WScript.Shell");
WSHShell.Run("H:/_BackupRestore/_BackUpXampp.cmd",0);